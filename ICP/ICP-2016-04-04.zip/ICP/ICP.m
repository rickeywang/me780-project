ptCloudFull = pcread('teapot.ply');

ptCloud = pcdownsample(ptCloudFull,'random',0.005);

% Apply transform
A = [cos(pi/6) sin(pi/6) 0 0; ...
    -sin(pi/6) cos(pi/6) 0 0; ...
            0         0  1 0; ...
            5         5  0 1];
        

tform1 = affine3d(A);

ptCloudTformed = pctransform(ptCloud,tform1);

% figure(1);
% showPointCloud(ptCloud);
% title('Teapot');


% figure(2);
% showPointCloud(ptCloudTformed);
% title('Transformed Teapot');


[point minDist] = min_dist_points(ptCloud, ptCloudTformed);


%% ICP - Algorithm

%% Compute weighting for each point
weighting = apply_weighting(minDist);
%% Eliminate outliers


%% Compute centroids of point clouds
centroidRef = [0 0 0];
centroidTformed = [0 0 0];

for i=1:ptCloud.Count
    centroidRef(1) = centroidRef(1) + ptCloud.Location(i,1);
    centroidRef(2) = centroidRef(2) + ptCloud.Location(i,2);
    centroidRef(3) = centroidRef(3) + ptCloud.Location(i,3);
end
centroidRef = centroidRef / ptCloud.Count;

for i=1:ptCloudTformed.Count
    centroidTformed(1) = centroidTformed(1) + ptCloudTformed.Location(i,1)*weighting(i);
    centroidTformed(2) = centroidTformed(2) + ptCloudTformed.Location(i,2)*weighting(i);
    centroidTformed(3) = centroidTformed(3) + ptCloudTformed.Location(i,3)*weighting(i);
end
%centroidTformed = centroidTformed / ptCloudTformed.Count;



%% Find translation between the 2 centroids
p = ptCloud.Location(:,:);
q = ptCloudTformed.Location(:,:);

q_centred = q - repmat(centroidRef,length(q),1);
p_centred = p - repmat(centroidTformed, length(p),1);

weight_matrix = diag(weighting);

%% Find the optimal rotation matrix between the 2 point clouds using SVD
N = p_centred' * weight_matrix * q_centred;
[U, ~ , V] = svd(N);
R = V*diag([1 1 det(U*V')])*transpose(U);
T = centroidTformed' - R*centroidRef';









    